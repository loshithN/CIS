package com.perisic.beds.recycling;

/**
 * Represents a bottle to be recycled.
 * @author Marc Conrad
 *
 */
public class Bag extends DepositItem {
	/**
	 * 
	 */
	public Bag() { 
		value = 45; 
	}
}
