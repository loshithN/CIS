package Week2;

import java.util.ArrayList;
import java.util.List;

public class Book{
	
	private String bookName;
	private String publisher;
	private List authors =new ArrayList<Person>();
	
	
	public Book(String bookName, String publisher) {
		super();
		this.bookName = bookName;
		this.publisher = publisher;
	}


	public String getBookName() {
		return bookName;
	}


	public void setBookName(String bookName) {
		this.bookName = bookName;
	}


	public String getPublisher() {
		return publisher;
	}



	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}



	public void setAuthors(List authors) {
		this.authors = authors;
	}


	public List getAuthors() 
	{
		return authors;
		
	}
	
	public void addAuthor(Person pname)
	{
      this.authors.add(pname.getName()+" ");
      this.authors.add(" Age:"+pname.getAge()+" ");
      this.authors.add(" Address:"+pname.getAddress()+"\n");
 
	}
	
	public void addAuthor(Professor pname) 
	{
      this.authors.add(pname.getName());
      this.authors.add(" Age:"+pname.getAge()+" ");
      this.authors.add(" Address:"+pname.getAddress()+" ");
      this.authors.add(" University:"+pname.getUniversity()+" ");
      this.authors.add(" Affiliation:"+pname.getAffiliation());
      
	}
	
	
	public void dsiplay() 
	{
		System.out.print("Book Name:"+this.getBookName());
		System.out.println(" Publisher:"+this.getPublisher());
		
		for(int i=0;i<authors.size();i++) 
		{
			System.out.print(this.getAuthors().get(i));
			if(i==4) 
			{
				System.out.println();
			}
		}
		
	}
	

}
