package Week2;

public class Professor extends Person{
	
	private String university;
	private String affiliation;
	

	public Professor(String pname, int age,String paddress,String setuni,String setaff) 
	{
		super(pname,age,paddress);
		this.setUniversity(setuni);
		this.setAffiliation(setaff);
		
	}


	public String getUniversity() {
		return university;
	}


	public void setUniversity(String university) {
		this.university = university;
	}


	public String getAffiliation() {
		return affiliation;
	}


	public void setAffiliation(String affiliation) {
		this.affiliation = affiliation;
	}
	
	

}
