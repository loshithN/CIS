package Week2;

import java.time.Instant;

public class Test {

	public static void main(String[] args) {
		
		Book bookObj = new Book("Head-First-Java","Oreilly");
		
		bookObj.addAuthor(new Professor("Kathy Sierra",63,"USA","Sun","Instructor")); 
		bookObj.addAuthor(new Person("Bert Bates",63,"USA"));
		
		bookObj.dsiplay();
		
		
	}
		// TODO Auto-generated method stub
		
		

}
